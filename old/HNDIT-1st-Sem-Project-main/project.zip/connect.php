<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "register";

	$con = mysqli_connect($server,$username,$password,$database);

	if (!$con) {
		die ("Not Connected to Database");
	}

?>